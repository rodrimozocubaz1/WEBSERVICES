<?php

date_default_timezone_set('America/Lima');

define('URL_LOGIN', 'http://' . $_SERVER['HTTP_HOST'] . '/ISCControl/login');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'asistencia2'); // CAMBIAR POR ASISTENCIA
define('DB_PORT', '3306');

// padre = locales
// hijo = departamento
// nieto = empleados
// 
// Permisos Ajax
$ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Tipos de Method
$is_post = strtoupper($_SERVER['REQUEST_METHOD']) === 'POST' || strtolower($_SERVER['REQUEST_METHOD']) === 'POST';
$is_get = strtoupper($_SERVER['REQUEST_METHOD']) === 'GET' || strtolower($_SERVER['REQUEST_METHOD']) === 'GET';

// Mensaje de error array
$json = array(
    'status' => 'Error',
    'msg' => 'Acceso Denegado.'
);

// Conexion a la base de datos
$link = mysqli_connect("localhost", "root", "", "asistencia2");
try {
    $pdo = new PDO('mysql:host='
            . DB_HOST
            . '; dbname=' . DB_NAME
            , DB_USER
            , DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
} catch (PDOException $message) {
    echo $message->getMessage();
}

