<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_get) {

        $cmd = htmlspecialchars(trim($_GET['cmd']));
        @$iddepartamento = htmlspecialchars(trim($_GET['iddepartamento']));

        if (strtolower($cmd) == 'lista-empleados') {
            $stm = "SELECT * FROM " . DB_NAME . ".`nieto` GROUP BY idnieto ORDER BY nieto;";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {
                $json['msg'] = 'Listado de empleados';
                $json['status'] = 'Ok';
                $json['data'] = $data;
            } else {
                $json['msg'] = 'El listado está vacio.';
            }
        } else if (strtolower($cmd) == 'lista-empleadosxdepartamento' && !empty(@$iddepartamento)) {
            $stm = "SELECT * FROM " . DB_NAME . ".`nieto` WHERE idhijo = " . @$iddepartamento . " GROUP BY idnieto ORDER BY nieto;";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {
                $json['msg'] = 'Listado de empleados por departamento';
                $json['status'] = 'Ok';
                $json['data'] = $data;
            } else {
                $json['msg'] = 'El listado de empleados por departamento está vacio.';
            }
        } else {
            $json['msg'] = 'Lista de empleados vacia.';
        }
    } else if ($is_post) {
        $cmd = htmlspecialchars(trim($_POST['cmd']));
        @$idempleado = htmlspecialchars(trim($_POST['search']));

        if ($cmd == 'buscarempleadohorario') {
            $stm = "SELECT idnieto,nieto FROM " . DB_NAME . ".`nieto` WHERE nieto LIKE '%" . @$idempleado . "%' GROUP BY idnieto ORDER BY nieto;";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {

                $datos = array();

                $json['msg'] = 'Listado de empleados para horario';
                $json['status'] = 'Ok';

                for ($d = 0; $d < count($data); $d++) {
                    $datos[] = array('value' => $data[$d]['idnieto'], 'label' => $data[$d]['nieto']);
                }
                $json['data'] = $datos;
            } else {
                $json['msg'] = $stm;
            }
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
