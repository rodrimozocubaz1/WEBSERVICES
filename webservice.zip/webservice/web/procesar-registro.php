<?php


    include "../conexion/dbconnect.php";
    include "../function/function.php";

$rutaWeb = "http://".$_SERVER['HTTP_HOST'] ."/webservice/web/procesar_horario.php";

if (trim($_GET["cmd"]) == 'reporteidoneo' && !empty(trim($_GET["nieto"])) 
    && !empty(trim($_GET["fecha1"])) && !empty(trim($_GET["fecha2"]))  && !empty(trim($_GET["horario"]))) {
    $nombre = $_GET["nieto"];
    $fecha1 = $_GET["fecha1"];
    $fecha2 = $_GET["fecha2"];
    $departamento = $_GET["departamento"];
    $local = $_GET["local"];
    $dni = $_GET["dni"];
    $c1 = $_GET["c1"];
    $c2 = $_GET["c2"];
    $c3 = $_GET["c3"];
    $c4 = $_GET["c4"];
    $c5 = $_GET["c5"];
    $c6 = $_GET["c6"];
    $horario = $_GET["horario"];    
    
    
    $link = mysqli_connect("localhost", "root", "", "asistencia2");
    
    $dtm13 = "SELECT COUNT(idturno) as u FROM fusion";
    $idturno =null;
    foreach ($pdo->query($dtm13) as $row) {
        $idturno = $row['u']; 
    }
    
    $num =null;
    $dtm11=null;
    if($c1 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c1', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    if($c2 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c2', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    if($c3 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c3', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    if($c4 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c4', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    if($c5 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c5', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    if($c6 != 0){
        $dtm11 = "INSERT INTO fusion (idturno,diasemana,idhorario) VALUES ('$idturno','$c6', '$horario')";
        mysqli_query($link,$dtm11);
        
    }
    
    $dtm22 = "INSERT INTO nieto (idnieto,idhijo,nieto,idturno) VALUES ('$dni','$departamento','$nombre',$idturno)";
    mysqli_query($link,$dtm22);
}
header("Location:".$_SERVER['HTTP_REFERER']. "?m=1");
?>

<script>
    //alert(" Volviendo atras");
    // para volver a una pagina anterior
    //window.history.back();
</script>