<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax

@$json = array();
$cmd = htmlspecialchars(trim($_POST['cmd']));
$nom = htmlspecialchars(trim($_POST['query']));

$tipo = '';
if(is_numeric($nom)){
    $tipo = 'num'; 
    $where = " idnieto LIKE '" . $nom . "%' ";
}else{
    $tipo = 'str';
    $where = " nieto LIKE '" . $nom . "%' ";
}

if ($cmd == 'buscar-empleado' && !empty($nom)) {
    $stm = "SELECT idnieto,nieto FROM " . DB_NAME . ".`nieto` WHERE " . $where ." GROUP BY idnieto ORDER BY nieto LIMIT 8;";
    $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);
    if ($data) {

        for ($i = 0; $i < count($data); $i++) {
            if($tipo == 'str'){
                @$json[] = @$data[$i]['nieto'];
            }else{
                @$json[] = @$data[$i]['idnieto'];
            }
        }
    } else {
        @$json[] = '';
    }
} else {
    @$json[] = '';
}
echo json_encode(@$json);


////'X-Requested-With', 'XMLHttpRequest'
//header('Content-Type: application/json');
//echo json_encode($json, JSON_UNESCAPED_UNICODE);

