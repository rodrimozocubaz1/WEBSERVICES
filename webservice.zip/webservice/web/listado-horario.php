<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_post) {
        $cmd = htmlspecialchars(trim($_POST['cmd']));
        @$idhorario = htmlspecialchars(trim($_POST['search']));

        if ($cmd == 'buscarhorarioparaempleado' && !empty(@$idhorario)) {
            $stm = "SELECT idhorario,CONCAT(entrada,' / ', salida) as horario FROM " . DB_NAME . ".`horario` WHERE CONCAT(entrada,' / ', salida) LIKE '%" . @$idhorario . "%' GROUP BY idhorario ORDER BY CONCAT(entrada,' / ', salida);";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {

                $datos = array();

                $json['msg'] = 'Listado de empleados para horario';
                $json['status'] = 'Ok';

                for ($d = 0; $d < count($data); $d++) {
                    $datos[] = array('value' => $data[$d]['idhorario'], 'label' => $data[$d]['horario']);
                }
                $json['data'] = $datos;
            } else {
                $json['msg'] = $stm;
            }
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);


