<?php


    include "../conexion/dbconnect.php";
    include "../function/function.php";

$rutaWeb = "http://".$_SERVER['HTTP_HOST'] ."/webservice/web/procesar_horario.php";

if (trim($_GET["cmd"]) == 'reporteidoneo' && !empty(trim($_GET["nieto"])) 
    && !empty(trim($_GET["fecha1"])) && !empty(trim($_GET["fecha2"]))  && !empty(trim($_GET["horario"]))) {
    $id = $_GET["nieto"];
    $fecha1 = $_GET["fecha1"];
    $fecha2 = $_GET["fecha2"];
    $c1 = $_GET["c1"];
    $c2 = $_GET["c2"];
    $c3 = $_GET["c3"];
    $c4 = $_GET["c4"];
    $c5 = $_GET["c5"];
    $c6 = $_GET["c6"];
    $horario = $_GET["horario"];    
    $link = mysqli_connect("localhost", "root", "", "asistencia2");
    
    
    $dtm11 = "SELECT idturno FROM nieto WHERE idnieto = '$id'";
    $num =null;
    foreach ($pdo->query($dtm11) as $row) {
        $num = $row['idturno']; 
    }
    $dtm22 = "SELECT diasemana, idhorario FROM fusion WHERE idturno = '$num'";
    foreach ($pdo->query($dtm22) as $row) {
        $dia = $row['diasemana'];
        $stm = "UPDATE fusion SET idhorario = '$horario' WHERE diasemana ='$dia'";
        if($row['diasemana'] == 1) {
            if($c1 != 0){
                mysqli_query($link,$stm);
                
            }
        }  else if($row['diasemana'] == 2) {
            if($c2 != 0){
                mysqli_query($link,$stm);
                 
            }
        }else if($row['diasemana'] == 3) {
            if($c3 != 0){
                mysqli_query($link,$stm);
                
            }
        } else if($row['diasemana'] == 4) {
            if($c4 != 0){
                mysqli_query($link,$stm);
                
            }
        } else if($row['diasemana'] == 5) {
            if($c5 != 0){
                mysqli_query($link,$stm);
               
            }
        } else if($row['diasemana'] == 6) {
            if($c6 != 0){
                mysqli_query($link,$stm);
                
            }
        }   
    }
}
header("Location:".$_SERVER['HTTP_REFERER']. "?m=1");
?>

<script>
    //alert(" Volviendo atras");
    // para volver a una pagina anterior
    //window.history.back();
</script>