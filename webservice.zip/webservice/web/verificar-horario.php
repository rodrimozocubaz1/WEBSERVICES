<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_get) {
        $cmd = htmlspecialchars(trim($_GET['cmd']));
        $he = htmlspecialchars(trim($_GET['he']));
        $hs = htmlspecialchars(trim($_GET['hs']));

        if ($cmd == 'verificarhorario' && !empty($he) && !empty($hs)){
            $stm = "SELECT idhorario FROM " . DB_NAME . ".`horario` WHERE entrada = '" . $he . "' AND salida = '" . $hs . "' GROUP BY idhorario LIMIT 1;";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);
            $cuenta = "SELECT COUNT(idhorario) as u FROM horario";
            $num =null;
            foreach ($pdo->query($cuenta) as $row) {
                $num = $row['u']; 
            }
            $num = $num +1;
            if ($data) {
                $json['msg'] = 'Horario encontrado.';
                $json['status'] = 'Ok';
                $json['data'] = array('idhorario' => $data[0]['idhorario']);
            } else if (!$data) {

                $insert = "INSERT INTO horario (idhorario,entrada,salida) VALUES (" . $num . ",'" . $he . "' , '" . $hs . "')";

                
                
                try {
                    $pdo->exec($insert);
                    $idhorario = $pdo->lastInsertId(); // return value is an integer
                    
                    $json['status'] = 'Ok';
                    $json['msg'] = 'El Horario encontrado y registrado, puede continuar.';
                    $json['data'] = array('idhorario' => $idhorario);
                } catch (Throwable $t) {
                    $json['msg'] = 'Hubo un error al registrar el horario.';
                    $json['data'] = array('idhorario' => '');
                }
            } else {
                $json['msg'] = 'El horario no fue encontrado.';
                $json['data'] = array('idhorario' => '');
            }
        } else {
            $json['msg'] = 'Uno de los campos están vacios.';
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
