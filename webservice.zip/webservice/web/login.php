<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_post) {
        $user = htmlspecialchars(trim($_POST['user']));
        $pass = htmlspecialchars(trim($_POST['pass']));

        if (empty($user)) {
            $json['msg'] = 'El campo nombre de usuarios es obligatorio.';
        } else if (empty($pass)) {
            $json['msg'] = 'El campo contraseña es obligatorio.';
        } else if (empty($user) && empty($pass)) {
            $json['msg'] = 'Todos los campos son obligatorio.';
        } else if (!empty($user) && empty(!$pass)) {
            $stm = "SELECT * FROM " . DB_NAME . ".administradores WHERE Nombres = '" . $user . "' AND Contraseña = '" . $pass . "' LIMIT 1;";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {

                session_start();
                session_regenerate_id(true);
                $_SESSION['acceso'] = true;
                $_SESSION['id'] = @$data[0]['Id'];
                $_SESSION['nombres'] = @$data[0]['Nombres'];
                $_SESSION['apellidos'] = @$data[0]['Apellidos'];
                $_SESSION['correo'] = @$data[0]['Correo'];
                $_SESSION['contraseña'] = @$data[0]['Contraseña'];
                $_SESSION['rol'] = @$data[0]['Rol'];
                
                // nombre y apellido completo corto
                $nom = explode(" ", @$data[0]['Nombres']);
                $ape = explode(" ", @$data[0]['Apellidos']);
                $_SESSION['primer_nombre'] = $nom[0];
                $_SESSION['nom_ape'] = $nom[0] . ' ' . $ape[0];
                // 
                
                $json['status'] = 'Ok';
                $json['msg'] = 'Bienvenido, ' . @$data[0]['Nombres'] . ' ' . @$data[0]['Apellidos'] . '.';
            } else {
                $json['msg'] = 'El nombre de usuario ó contraseña es incorrecta.';
            }
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
