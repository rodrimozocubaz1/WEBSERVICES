<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_get) {

        $cmd = htmlspecialchars(trim($_GET['cmd']));
        @$idlocal = htmlspecialchars(trim($_GET['idlocal']));

        if (strtolower($cmd) == 'lista-departamentoxlocal' & !empty(@$idlocal)) {            
            $stm = "SELECT * FROM " . DB_NAME . ".`hijo` WHERE idpadre = " . $idlocal;
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {
                $json['msg'] = 'Listado de Departamentos';
                $json['status'] = 'Ok';
                $json['data'] = $data;
            } else {
                $json['msg'] = 'El listado está vacio.';
            }
        } else {
            $json['msg'] = 'cmd no reconocido.';
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
