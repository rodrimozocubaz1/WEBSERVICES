<?php
include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_get) {
        
    } else if ($is_post) {
        
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
