<?php

include "../conexion/dbconnect.php";
include "../function/function.php";

// Metodo solo permitido por ajax
if ($ajax) {
    if ($is_post) {
        $cmd = htmlspecialchars(trim($_POST['cmd']));

        if ($cmd == 'lista-departamento') {
            $stm = "SELECT hijo FROM " . DB_NAME . ".`hijo`";
            $data = $pdo->query($stm)->fetchAll(PDO::FETCH_ASSOC);

            if ($data) {

                $datos = array();

                $json['msg'] = 'Listado de departamentos';
                $json['status'] = 'Ok';

                for ($d = 0; $d < count($data); $d++) {
                    $datos[] = array('value' => $data[$d]['hijo'], 'label' => $data[$d]['hijo']);
                }
                $json['data'] = $datos;
            } else {
                $json['msg'] = $stm;
            }
        }
    } else {
        $json['msg'] = 'Metodo request no reconocido';
    }
}

//'X-Requested-With', 'XMLHttpRequest'
header('Content-Type: application/json');
echo json_encode($json, JSON_UNESCAPED_UNICODE);
